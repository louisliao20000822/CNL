from mininet.topo import Topo

class MyTopo(Topo):
	#Setup
	def __init__( self ):
		Topo.__init__( self )
	#Create Topology
	#Add host and switch
		H1 = self.addHost("h1")
		H2 = self.addHost("h2")
		H3 = self.addHost("h3")
		H4 = self.addHost("h4")
		H5 = self.addHost("h5")
		H6 = self.addHost("h6")
		H7 = self.addHost("h7")
		H8 = self.addHost("h8")
		H9 = self.addHost("h9")
		H10 = self.addHost("h10")
		H11 = self.addHost("h11")
		H12 = self.addHost("h12")
		H13 = self.addHost("h13")
		H14 = self.addHost("h14")
		H15 = self.addHost("h15")
		H16 = self.addHost("h16")
		
		S1 = self.addSwitch("s1")
		S2 = self.addSwitch("s2")
		S3 = self.addSwitch("s3")
		S4 = self.addSwitch("s4")
		S5 = self.addSwitch("s5")
		S6 = self.addSwitch("s6")
		S7 = self.addSwitch("s7")
		S8 = self.addSwitch("s8")
		S9 = self.addSwitch("s9")
		S10 = self.addSwitch("s10")
		S11 = self.addSwitch("s11")
		S12 = self.addSwitch("s12")
		S13 = self.addSwitch("s13")
		S14 = self.addSwitch("s14")
		S15 = self.addSwitch("s15")
		S16 = self.addSwitch("s16")
		S17 = self.addSwitch("s17")
		S18 = self.addSwitch("s18")
		S19 = self.addSwitch("s19")
		S20 = self.addSwitch("s20")
	#Add links
		#S1
		self.addLink(S1,S5)
		self.addLink(S1,S7)
		self.addLink(S1,S9)
		self.addLink(S1,S11)
		#S2
		self.addLink(S2,S6)
		self.addLink(S2,S8)
		self.addLink(S2,S10)
		self.addLink(S2,S12)
		#S3
		self.addLink(S3,S5)
		self.addLink(S3,S7)
		self.addLink(S3,S9)
		self.addLink(S3,S11)
		#S4
		self.addLink(S4,S6)
		self.addLink(S4,S8)
		self.addLink(S4,S10)
		self.addLink(S4,S12)
		#A1
		self.addLink(S5,S13)
		self.addLink(S5,S14)
		self.addLink(S6,S13)
		self.addLink(S6,S14)
		#A2
		self.addLink(S7,S15)
		self.addLink(S7,S16)
		self.addLink(S8,S15)
		self.addLink(S8,S16)
		#A3
		self.addLink(S9,S17)
		self.addLink(S9,S18)
		self.addLink(S10,S17)
		self.addLink(S10,S18)
		#A4
		self.addLink(S11,S19)
		self.addLink(S11,S20)
		self.addLink(S12,S19)
		self.addLink(S12,S20)
		#E1
		self.addLink(S13,H1)
		self.addLink(S13,H2)
		self.addLink(S14,H3)
		self.addLink(S14,H4)
		#E2
		self.addLink(S15,H5)
		self.addLink(S15,H6)
		self.addLink(S16,H7)
		self.addLink(S16,H8)
		#E3
		self.addLink(S17,H9)
		self.addLink(S17,H10)
		self.addLink(S18,H11)
		self.addLink(S18,H12)
		#E4
		self.addLink(S19,H13)
		self.addLink(S19,H14)
		self.addLink(S20,H15)
		self.addLink(S20,H16)
	#Name topology part
topos = {"mytopo":(lambda:MyTopo())}
