from operator import attrgetter

import simple_switch_13
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, DEAD_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.lib import hub 
import subprocess
class SimpleMonitor13(simple_switch_13.SimpleSwitch13):

    def __init__(self, *args, **kwargs):
        super(SimpleMonitor13, self).__init__(*args, **kwargs)
        self.datapaths = {}
        self.monitor_thread = hub.spawn(self._monitor)
        self.flow_byte_counts = {}
        self.simple_dpids = {0x1: "s1", 0x2: "s2",0x3: "s3", 0x4: "s4"}
    def apply_rate_limiting(self,switch,src_ip,src_port,dst_ip,dst_port,protocol):
        print("dropped")
        #ingressPolicingBurst, ingressPolicingRate = "ingress_policing_burst=10", "ingress_policing_rate=5000"
        subprocess.call(["sudo", "ovs-ofctl", "mod-flows",switch,"ip,nw_src="+src_ip+",nw_dst="+dst_ip+",nw_proto=6,tp_src="+str(src_port)+",tp_dst="+str(dst_port)+",actions=drop"])

    @set_ev_cls(ofp_event.EventOFPStateChange,
                [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def _state_change_handler(self, ev):
        datapath = ev.datapath
        if ev.state == MAIN_DISPATCHER:
            if datapath.id not in self.datapaths:
                self.logger.debug('register datapath: %016x', datapath.id)
                self.datapaths[datapath.id] = datapath
        elif ev.state == DEAD_DISPATCHER:
            if datapath.id in self.datapaths:
                self.logger.debug('unregister datapath: %016x', datapath.id)
                del self.datapaths[datapath.id]

    def _monitor(self):
        while True:
            for dp in self.datapaths.values():
                self._request_stats(dp)
            hub.sleep(10)

    def _request_stats(self, datapath):
        self.logger.debug('send stats request: %016x', datapath.id)
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        req = parser.OFPFlowStatsRequest(datapath)
        datapath.send_msg(req)

        req = parser.OFPPortStatsRequest(datapath, 0, ofproto.OFPP_ANY)
        datapath.send_msg(req)

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def _flow_stats_reply_handler(self, ev):
        body = ev.msg.body
        dpid = int(ev.msg.datapath.id)
        switch = self.simple_dpids[dpid]
        self.logger.info('datapath         '
                         'in-port  match src_ip   src_port    dst_ip  dst_port  protocol '
                         'action  packets  bytes')
        self.logger.info('---------------- '
                         '-------- ----------------------------------------------------- '
                         '-------- -------- --------')

        for stat in sorted([flow for flow in body if flow.priority == 1],
                           key=lambda flow: (flow.match['in_port'])):	
            #if isinstance(stat.instructions[0].actions[0],str) :
            if not stat.instructions :
                self.logger.info('%016x %8d %14s %8s %10s %8s %8s %8s %8d %8d',ev.msg.datapath.id,stat.match['in_port'],stat.match['ipv4_src'],stat.match['tcp_src'],stat.match['ipv4_dst'],stat.match['tcp_dst'],stat.match['ip_proto'],"dropped",
                             stat.packet_count, stat.byte_count)#stat.instructions[0].actions[0].port
            else:
                self.logger.info('%016x %8d %14s %8s %10s %8s %8s %8x %8d %8d',ev.msg.datapath.id,stat.match['in_port'],stat.match['ipv4_src'],stat.match['tcp_src'],stat.match['ipv4_dst'],stat.match['tcp_dst'],stat.match['ip_proto'],stat.instructions[0].actions[0].port,
                             stat.packet_count, stat.byte_count)#stat.instructions[0].actions[0].port
            
            src_ip = stat.match['ipv4_src']
            src_port = stat.match['tcp_src']
            dst_ip = stat.match['ipv4_dst']
            dst_port = stat.match['tcp_dst']
            protocol = stat.match['ip_proto']

            key = (src_ip, src_port, dst_ip, dst_port, protocol)
            rate = 0
            if key in self.flow_byte_counts:
                cnt = self.flow_byte_counts[key]
                rate = self.bitrate(stat.byte_count - cnt)
            else :
                rate = self.bitrate(stat.byte_count)
            self.flow_byte_counts[key] = stat.byte_count
            print("rate = %f KB/s" % rate)
            if rate > 1000 :
                self.apply_rate_limiting(switch,src_ip,src_port,dst_ip,dst_port,protocol)

            #print("src_ip %8s src_port %8s dst_ip %8s dst_port %8s protocol %8s rate %f" % (src_ip, src_port, dst_ip, dst_port, protocol,rate))
    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def _port_stats_reply_handler(self, ev):
        body = ev.msg.body
	#print(body)
        self.logger.info('datapath         port     '
                         'rx-pkts  rx-bytes error '
                         'tx-pkts  tx-bytes dropped')
        self.logger.info('---------------- -------- '
                         '-------- ---------- ---------- '
                         '-------- -------- --------  ----------')
        for stat in sorted(body):
	    sec=int(stat.duration_sec)
            self.logger.info('%016x %8x %8d %8d %8d %8d %8d %8d',
                             ev.msg.datapath.id, stat.port_no,
                             stat.rx_packets, stat.rx_bytes, stat.rx_errors+stat.tx_errors,
                             stat.tx_packets, stat.tx_bytes, stat.rx_dropped+stat.tx_dropped)


    # Convert from byte count delta to bitrate
    def bitrate(self,bytes):
        return bytes / 1024



